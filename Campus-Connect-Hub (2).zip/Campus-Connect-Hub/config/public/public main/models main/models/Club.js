const mongoose = require("mongoose");

const ClubSchema = new mongoose.Schema({
  name: String,
  category: String,
  description: String,
  isPrivate: Boolean,
  members: [{ type: mongoose.Schema.Types.ObjectId, ref: "Student" }]
});

module.exports = mongoose.model("Club", ClubSchema);
