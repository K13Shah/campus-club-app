const express = require("express");
const router = express.Router();
const Join = require("../models/JoinRequest");
const Club = require("../models/Club");

router.post("/request", async (req, res) => {
  const join = await Join.create(req.body);
  res.json(join);
});

router.post("/approve", async (req, res) => {
  const { requestId } = req.body;

  const reqData = await Join.findById(requestId);
  reqData.status = "approved";
  await reqData.save();

  const club = await Club.findById(reqData.clubId);
  club.members.push(reqData.studentId);
  await club.save();

  res.json("Approved");
});

module.exports = router;
