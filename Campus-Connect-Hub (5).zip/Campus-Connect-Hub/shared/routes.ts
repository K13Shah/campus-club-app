import { z } from 'zod';
import { 
  insertProfileSchema, 
  insertClubSchema, 
  insertEventSchema, 
  insertPostSchema, 
  insertCommentSchema,
  profiles,
  clubs,
  events,
  posts,
  clubMembers
} from './schema';

export const errorSchemas = {
  validation: z.object({
    message: z.string(),
    field: z.string().optional(),
  }),
  notFound: z.object({
    message: z.string(),
  }),
  internal: z.object({
    message: z.string(),
  }),
};

export const api = {
  profiles: {
    get: {
      method: 'GET' as const,
      path: '/api/profiles/me' as const,
      responses: {
        200: z.custom<typeof profiles.$inferSelect>(),
        404: errorSchemas.notFound,
      },
    },
    update: {
      method: 'PUT' as const,
      path: '/api/profiles/me' as const,
      input: insertProfileSchema.partial(),
      responses: {
        200: z.custom<typeof profiles.$inferSelect>(),
        400: errorSchemas.validation,
      },
    },
    create: {
      method: 'POST' as const,
      path: '/api/profiles' as const,
      input: insertProfileSchema,
      responses: {
        201: z.custom<typeof profiles.$inferSelect>(),
        400: errorSchemas.validation,
      },
    }
  },
  clubs: {
    list: {
      method: 'GET' as const,
      path: '/api/clubs' as const,
      input: z.object({
        category: z.string().optional(),
        search: z.string().optional(),
      }).optional(),
      responses: {
        200: z.array(z.custom<typeof clubs.$inferSelect>()),
      },
    },
    get: {
      method: 'GET' as const,
      path: '/api/clubs/:id' as const,
      responses: {
        200: z.custom<typeof clubs.$inferSelect & { isMember?: boolean, role?: string }>(),
        404: errorSchemas.notFound,
      },
    },
    create: {
      method: 'POST' as const,
      path: '/api/clubs' as const,
      input: insertClubSchema,
      responses: {
        201: z.custom<typeof clubs.$inferSelect>(),
        400: errorSchemas.validation,
      },
    },
    recommend: {
      method: 'GET' as const,
      path: '/api/clubs/recommendations' as const,
      responses: {
        200: z.array(z.custom<typeof clubs.$inferSelect>()),
      },
    },
    join: {
      method: 'POST' as const,
      path: '/api/clubs/:id/join' as const,
      responses: {
        200: z.object({ status: z.string() }),
        404: errorSchemas.notFound,
      },
    },
    members: {
      method: 'GET' as const,
      path: '/api/clubs/:id/members' as const,
      responses: {
        200: z.array(z.custom<typeof clubMembers.$inferSelect & { user: any }>()),
      },
    }
  },
  events: {
    list: {
      method: 'GET' as const,
      path: '/api/events' as const,
      input: z.object({
        clubId: z.string().optional(),
      }).optional(),
      responses: {
        200: z.array(z.custom<typeof events.$inferSelect>()),
      },
    },
    create: {
      method: 'POST' as const,
      path: '/api/events' as const,
      input: insertEventSchema,
      responses: {
        201: z.custom<typeof events.$inferSelect>(),
        400: errorSchemas.validation,
      },
    },
    rsvp: {
      method: 'POST' as const,
      path: '/api/events/:id/rsvp' as const,
      input: z.object({ status: z.enum(['going', 'maybe', 'not_going']) }),
      responses: {
        200: z.object({ status: z.string() }),
      },
    }
  },
  posts: {
    list: {
      method: 'GET' as const,
      path: '/api/clubs/:id/posts' as const,
      responses: {
        200: z.array(z.custom<typeof posts.$inferSelect & { author: any, comments: any[] }>()),
      },
    },
    create: {
      method: 'POST' as const,
      path: '/api/clubs/:id/posts' as const,
      input: insertPostSchema.omit({ clubId: true, authorId: true }),
      responses: {
        201: z.custom<typeof posts.$inferSelect>(),
      },
    }
  }
};

export function buildUrl(path: string, params?: Record<string, string | number>): string {
  let url = path;
  if (params) {
    Object.entries(params).forEach(([key, value]) => {
      if (url.includes(`:${key}`)) {
        url = url.replace(`:${key}`, String(value));
      }
    });
  }
  return url;
}
